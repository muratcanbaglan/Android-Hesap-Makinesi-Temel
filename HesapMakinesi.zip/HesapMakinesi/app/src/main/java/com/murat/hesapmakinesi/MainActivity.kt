package com.murat.hesapmakinesi

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.murat.hesapmakinesi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {



    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


    }

    fun topla(view: View){
        var plainText1 = binding.editText1.text.toString().toDoubleOrNull()
        var plaintText2 = binding.editText2.text.toString().toDoubleOrNull()

        if (plainText1 == null || plaintText2 == null){
            Toast.makeText(this@MainActivity,"Boş veya Geçersiz Karakterler",Toast.LENGTH_SHORT).show()
        }else{
            binding.textView2.text = "Sonuç : ${plainText1!! + plaintText2!!}"
        }
    }
    fun cikar(view: View){
        var plainText1 = binding.editText1.text.toString().toDoubleOrNull()
        var plaintText2 = binding.editText2.text.toString().toDoubleOrNull()
        if (plainText1 == null || plaintText2 == null){
            Toast.makeText(this@MainActivity,"Boş veya Geçersiz Karakterler",Toast.LENGTH_SHORT).show()
        }else{
            binding.textView2.text = "Sonuç : ${plainText1!! - plaintText2!!}"
        }
    }
    fun carp(view: View){
        var plainText1 = binding.editText1.text.toString().toDoubleOrNull()
        var plaintText2 = binding.editText2.text.toString().toDoubleOrNull()
        if (plainText1 == null || plaintText2 == null){
            Toast.makeText(this@MainActivity,"Boş veya Geçersiz Karakterler",Toast.LENGTH_SHORT).show()
        }else{
            binding.textView2.text = "Sonuç : ${plainText1!! * plaintText2!!}"
        }
    }
    fun bol(view: View){
        var plainText1 = binding.editText1.text.toString().toDoubleOrNull()
        var plaintText2 = binding.editText2.text.toString().toDoubleOrNull()
        if (plainText1 == null || plaintText2 == null){
            Toast.makeText(this@MainActivity,"Boş veya Geçersiz Karakterler",Toast.LENGTH_SHORT).show()
        }else{
            binding.textView2.text = "Sonuç : ${plainText1!! / plaintText2!!}"
        }
    }

}
